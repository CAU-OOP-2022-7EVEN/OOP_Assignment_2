#ifndef OOP_ASSIGNMENT_2_UIMANAGER_H
#define OOP_ASSIGNMENT_2_UIMANAGER_H

void openMainMenu(int, char**);

#endif