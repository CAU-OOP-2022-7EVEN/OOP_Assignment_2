Environment
- OS : Ubuntu 20.04.1 Desktop
- Architecture : amd64
- Compiler : Cmake 3.23

Project Structure
- Directory Root( ./ ) : Source Code for Presentation - Includes QT GUI Related Code. So it would not be compiled without QT Development Environment
- Directory OOP_Assignment2_VS : Source Code for Assignment Submit. Professer can run codes inside this directory with Visual Studio.

Execution
- If QT Development Environment is NOT Setted
-> Open OOP_Assignment2_VS Directory with Visual Studio.
- If QT Development Environment is Setted
-> Just run Root Directory as CMake Project.