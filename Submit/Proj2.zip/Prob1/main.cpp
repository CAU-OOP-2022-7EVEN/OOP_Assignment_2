#include <iostream>
#include "inf_int.h"
#include "inf_int_test.h"
#include "UIManager.h"

using namespace std;

int main(int argc, char** argv){
    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(false);

//    inf_int_test::TestDefault();
//    inf_int_test::TestOperate100digitsWith50digits();

    openMainMenu(argc, argv);

    return 0;
}
